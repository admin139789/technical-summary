requirejs.config({
    paths: {
        page: '../../module/declareManagement/view/page.html',
    }
});
define(['vue', 'text!page', 'util', 'notify', 'datetime'], function(Vue, page, util, notify) {
    Vue.component('page', {
        template: page,
        data: function() {
            return {
                args: {},
                argsFlag: false,
                show: false,
                warehouse: {
                    id: this.type + 'warehouse',
                    callback: this.type + 'warehouse_callback'
                },
                supplier: {
                    id: this.type + 'supplier',
                    callback: this.type + 'supplier_callback'
                },
                flyStart: {
                    id: this.type + 'flyStart',
                    callback: this.type + 'flyStart_callback'
                },
                channel: {
                    id: this.type + 'channel',
                    callback: this.type + 'channel_callback'
                },
                airline: {
                    id: this.type + 'airline',
                    callback: this.type + 'airline_callback'
                },
                head: this.type + 'head',
                //headData start
                detailArgs: {},
                deleteInfoArr: [],
                //headData end
                requestCode: '',
                files: [],
                fileSelect: [],
                createFlag: false,
                editFlag: false,
                resetForm: false,
                infoFlag: false,
                fileFlag: false,
                TXN_TIME: ''
            }
        },
        methods: {
            getInfoGridArr: function() {
                var self = this;
                if (this.type == "detail") {
                    return [
                        { id: "AIR_LINE_SUPPLIER_NAME", name: '<i class="star">*</i>航线', field: "AIR_LINE_SUPPLIER_NAME" },
                        { id: "DESTINATION_CITY_NAME", name: '<i class="star">*</i>目的地', field: "DESTINATION_CITY_NAME" },
                        { id: "FLIGHT_NUMBER", name: '<i class="star">*</i>航班号', field: "FLIGHT_NUMBER" },
                        { id: "B_L_NUMBER_NAME", name: '提单号', field: "B_L_NUMBER_NAME" },
                        { id: "BILL_NUMBER", name: '<i class="star">*</i>票据号', field: "BILL_NUMBER" },
                        { id: "GROCERIES", name: '<i class="star">*</i>杂货', field: "GROCERIES", formatter: self.checkBoxFormatter },
                        { id: "GOODS_TYPE_NAMES", name: '<i class="star">*</i>货物类别', field: "GOODS_TYPE_NAMES" },
                        { id: "GOODS_AMOUNT", name: '件数', field: "GOODS_AMOUNT" },
                        { id: "GOODS_WEIGHT", name: '重量', field: "GOODS_WEIGHT" },
                        { id: "GOODS_VOLUMN", name: '体积', field: "GOODS_VOLUMN" },
                        { id: "GOODS_STATUS", name: '货物状态', field: "GOODS_STATUS" },
                        { id: "B_NUM", name: '行李号', field: "B_NUM" }
                    ];

                } else {
                    $(document).off('integer:false').on('integer:false', function(e) {
                        self.notifyError({
                            title: '数据类型错误',
                            text: '该输入框只能输入整数!'
                        });
                    });
                    $(document).off('float:false').on('float:false', function(e) {
                        self.notifyError({
                            title: '数据类型错误',
                            text: '该输入框只能输入浮点数，保留两位小数!'
                        });
                    });
                    return [
                        //{ id: "AIR_LINE_SUPPLIER_NAME", name: '<i class="star">*</i>航线', field: "AIR_LINE_SUPPLIER_NAME", editor: Slick.Editors.selectFilter, option: { key: "SUPPLIER", filterData: '[{"STATUS":"1"},{"SUPPLIER_TYPE": "CRM_SUPPLIER2"}]', callback: 'AIR_WAY', url: '/tad/select' } },
                    	{id:"AIR_LINE_SUPPLIER_NAME",name: '<i class="star">*</i>航线',field:"AIR_LINE_SUPPLIER_NAME",sortable:true,editor: Slick.Editors.selectFilterAsync, option: { key: "",  callback: 'FLIGHT_ROUTE', url: '/supplier/getSuppByType?SUPPLIER_TYPE=CRM_SUPPLIER2' }},
                    	{ id: "DESTINATION_CITY_NAME", name: '目的地', field: "DESTINATION_CITY_NAME" },
                        { id: "FLIGHT_NUMBER", name: '<i class="star">*</i>航班号', field: "FLIGHT_NUMBER", editor: Slick.Editors.Text },
                        { id: "B_L_NUMBER_NAME", name: '提单号', field: "B_L_NUMBER_NAME", editor: Slick.Editors.selectFilterAsync, option: { key: "B_L_MANAGE_INFO_DECLARE",inputLessLenght:3, filterData: '[]', callback: 'MANAGE_INFO', url: '/tad/select' }},
                        // , editor: Slick.Editors.selectFilter, option: { key: "B_L_MANAGE_INFO", filterData: '[{"STATUS":"NU"}]', callback: 'MANAGE_INFO', url: '/tad/select' }
                        { id: "BILL_NUMBER", name: '票据号', field: "BILL_NUMBER" },
                        { id: "GROCERIES", name: '杂货', field: "GROCERIES", formatter: self.checkBoxFormatter },
                        { id: "GOODS_TYPE_NAMES", name: '<i class="star">*</i>货物类别', field: "GOODS_TYPE_NAMES", editor: Slick.Editors.filterSelect, option: { key: "GOODS_CATEGORY", filterData: '[{"STATUS":"1"}]', callback: 'GOODSCATEGORY_NAME', url: '/tad/select', multiple: true } },
                        { id: "GOODS_AMOUNT", name: '件数', field: "GOODS_AMOUNT", editor: Slick.Editors.Integer, tip: 'true' },
                        { id: "GOODS_WEIGHT", name: '重量', field: "GOODS_WEIGHT", editor: Slick.Editors.Float, tip: 'true' },
                        { id: "GOODS_VOLUMN", name: '体积', field: "GOODS_VOLUMN", editor: Slick.Editors.Float, tip: 'true' },
                        { id: "CATEGORY", name: '货物状态', field: "CATEGORY" },
                        { id: "B_NUM", name: '行李号', field: "B_NUM" }
                    ];
                }
            },
            getFileGridArr: function() {
                var self = this;
                return [
                    { id: "ORIGINAL_NAME", name: '<i class="star">*</i>文件', field: "ORIGINAL_NAME" },
                    { id: "UPLOAD_TIME", name: '<i class="star">*</i>上传时间', field: "UPLOAD_TIME" },
                    { id: "UPLOADER", name: '<i class="star">*</i>上传人', field: "UPLOADER" },
                    { id: "REMARK", name: "备注", field: "REMARK" },
                    { id: "OPTION", name: "操作", formatter: self.checkFormatter },
                ];
            },
            checkFormatter: function(row, cell, value, columnDef, dataContext) {
                return '<a style="color:red;" type="button" href="' + dataContext.FILE_URL + '" target="blank">查看文件</a>';
            },
            checkBoxFormatter: function(row, cell, value, columnDef, dataContext) {
                if (value == '0') {
                    return '<input type="checkbox" disabled>';
                } else {
                    return '<input type="checkbox" checked disabled>';
                }
            },
            slide: function(e) {
                var self = this;
                var slide = $(self.$el).find('.modal-slide-form');
                slide.slideToggle();
                $(self.$el).find('.icon').toggleClass('fa-level-up');
                $(self.$el).find('.icon').toggleClass('fa-level-down');
            },
            loadShipmentSlide: function() {
                $('.item-import-query').slideToggle();
            },
            removeFile: function() {
                var self = this;
                var rows = self.file.getSelectedRows(); // 获取选中行

                for (var i = 0, l = rows.length; i < l; i++) {
                    if (rows[i] == self.file.getDataLength()) {
                        rows.splice(i, 1);
                    } else {
                        var item = self.file.getDataItem(i);
                        self.fileSelect.push(item.FILE_ID);
                    }
                }
                if (self.fileSelect.length > 0) {
                    var url = window.domain + '/declaremanagement/delUploadedFile';
                    var ids = self.fileSelect.join(',');
                    var data = {
                        uploadedFileIds: ids
                    };
                    self.getMask();
                    self.getAjax(url, data, function(res) {
                        self.removeMask();
                        if (res.success) {
                            var data = self.file.getData();
                            var k = 0;
                            for (var n = 0, m = rows.length; n < m; n++) {
                                data.splice(rows[n] - k, 1);
                                k++;
                            }
                            self.grid = self.getGridEdit(data, self.getFileGridArr(), "#" + self.type + '_file');
                            self.notifySuc({
                                title: '文件操作',
                                text: '文件删除成功'
                            });
                        } else {
                            self.notifyError({
                                title: '文件操作',
                                text: '文件删除失败'
                            });
                        }
                    });
                } else {
                    self.notifyWarn({
                        title: '文件操作',
                        text: '请先选择一条数据！'
                    });
                }
            },
            uploadFile: function() {
                var self = this;
                var setting = self.fileSetting();
                var form = $('[name="' + self.type + 'file"]');
                form.formValidation(setting).formValidation('validate');
                var flag = form.data('formValidation').isValid();
                if (flag) {
                    var url = window.domain + '/declaremanagement/uploadFile?';
                    !self.requestCode ? url += 'Declare.AIR_DECLARE_ID=' + self.args.AIR_DECLARE_ID : url += 'requestCode=' + self.requestCode;
                    var formData = new FormData(form[0]);
                    //console.log(formData);
                    self.getMask();
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(args) {
                            self.removeMask();
                            //console.log(args);
                            if (args.success) {
                                var filesMsg = args.data.uploadFiles;
                                for (var i = 0, l = filesMsg.length; i < l; i++) {
                                    self.files.push(filesMsg[i]);
                                }
                                self.file = self.getGridEdit(self.files, self.getFileGridArr(), "#" + self.type + '_file');
                                //console.log(self.grid);
                                form.find('[name="file"], [name="remarks"]').val('');
                                form.data('formValidation').resetForm();
                                self.notifySuc({
                                    title: '文件操作',
                                    text: '文件上传成功'
                                });
                                self.fileFlag = true; //标记清除
                            } else {
                                self.notifyError({
                                    title: '文件上传操作',
                                    text: '文件上传失败'
                                });
                                //console.log('file upload msg:', args);
                            }
                        },
                        error: function() {

                        }
                    });
                }
            },
            fileSetting: function() {
                return {
                    framework: 'bootstrap',
                    icon: {
                        valid: 'glyphicon glyphicon-ok',
                        invalid: 'glyphicon glyphicon-remove',
                        validating: 'glyphicon glyphicon-refresh'
                    },
                    fields: {
                        'file': {
                            validators: {
                                notEmpty: {
                                    message: ''
                                }
                            }
                        }
                    }
                };
            },

            warehouseEntry: function() {
                var self = this;
                var item = self.getSelectId();
                if (item) {
                    var data = {
                        'DeclareDetail.AIR_DECLARE_INFO_ID': item.id,
                        'DeclareDetail.LAST_TXN_TIME': item.time,
                        action: 'WAREHOUSING'
                    };
                    var flag = {
                        row: item.row,
                        status: 'EC'
                    }
                    self.infoOptionSend(data, '进仓', flag);
                }
            },
            stockChecking: function() {
                var self = this;
                var item = self.getSelectId();
                if (item) {
                    var data = {
                        'DeclareDetail.AIR_DECLARE_INFO_ID': item.id,
                        'DeclareDetail.LAST_TXN_TIME': item.time,
                        action: 'INSPECTION'
                    };
                    var flag = {
                        row: item.row,
                        status: 'CC'
                    }
                    self.infoOptionSend(data, '查货', flag);
                }
            },
            release: function() {
                var self = this;
                var item = self.getSelectId();
                if (item) {
                    var data = {
                        'DeclareDetail.AIR_DECLARE_INFO_ID': item.id,
                        'DeclareDetail.LAST_TXN_TIME': item.time,
                        action: 'CLEARANCE'
                    };
                    var flag = {
                        row: item.row,
                        status: 'DI'
                    }
                    self.infoOptionSend(data, '放行', flag);
                }
            },
            releaseCancel: function() {
                var self = this;
                var item = self.getSelectId();
                if (item) {
                    var data = {
                        'DeclareDetail.AIR_DECLARE_INFO_ID': item.id,
                        'DeclareDetail.LAST_TXN_TIME': item.time,
                        action: 'CANCELCLEARANCE'
                    };
                    var flag = {
                        row: item.row,
                        status: ''
                    }
                    self.infoOptionSend(data, '撤销放行', flag);
                }
            },
            getSelectId: function() {
                var self = this;
                var row = self.info.getSelectedRows();
                var item = self.info.getDataItem(row);
                if (item == undefined) {
                    self.notifyWarn({
                        title: '报关信息操作',
                        text: '请先选择一条报关信息！'
                    });
                    return false;
                } else {
                    //console.log("item id: ", item.AIR_DECLARE_INFO_ID);
                    return {
                        id: item.AIR_DECLARE_INFO_ID,
                        time: item.LAST_TXN_TIME,
                        row: row
                    };
                }

            },
            infoOptionSend: function(data, type, flag) {
                var url = window.domain + '/declaremanagement/changeDeclareDetailStatus';
                var self = this;
                //console.log("info option flag: ", flag);
                /*
                switch(data.action) {
                    case 'WAREHOUSING':
                        var btn = $('[opt-type="warehouseEntry"]');
                        break;
                    case 'INSPECTION':
                        var btn = $('[opt-type="stockChecking"]');
                        break;
                    case 'CLEARANCE':
                        var btn = $('[opt-type="release"]');
                        break;
                }
                btn.prop('disabled', 'disabled');*/
                //setTimeout(function(){btn.removeProp('disabled');}, 1000)
                self.getMask();
                //setTimeout(function(){self.removeMask();}, 2000);
                //self.removeMask();
                self.getAjax(url, data, function(res) {
                    if (res.success) {
                        var infoData = self.info.getData();
                        infoData[flag.row].GOODS_STATUS = self.stateFilter(flag.status);
                        //console.log("state change grid:", infoData);
                        self.info = self.getGrid(infoData, self.getInfoGridArr(), "#" + self.type + '_info');
                        self.notifySuc({
                            title: '报关信息操作',
                            text: '报关信息' + type + '成功！'
                        });
                        //本单的全部明细状态为放行时，本单状态改为已起飞
                        if(res.message =='ok'){
                        	self.args.CURRENT_STATUS ="DI";
                        	self.detailArgs.CURRENT_STATUS ="DI";
                        }
                        
                        if(data.action=='CANCELCLEARANCE'){//撤销放行
                        	self.args.CURRENT_STATUS ="SD";
                        	self.detailArgs.CURRENT_STATUS ="SD";
                        }
                        
                    } else {
                        //console.log('option res:', res);
                        self.notifyError({
                            title: '报关信息操作',
                            text: '当前状态不允许' + type
                        });
                    }
                    //btn.removeProp('disabled');
                    self.removeMask();
                })
            },
            headSetting: function() {
                return {
                    framework: 'bootstrap',
                    icon: {
                        valid: 'glyphicon glyphicon-ok',
                        invalid: 'glyphicon glyphicon-remove',
                        validating: 'glyphicon glyphicon-refresh'
                    },
                    fields: {
                        'Declare.SCHEDULE_DATE': {
                            validators: {
                                notEmpty: {
                                    message: ''
                                }
                            }
                        },
                        'Declare.WARE_HOUSE_ID': {
                            validators: {
                                notEmpty: {
                                    message: ''
                                }
                            }
                        },
                       /* 'Declare.CUSTOMS_BROKER_SUPPLIER_ID': {
                            validators: {
                                notEmpty: {
                                    message: ''
                                }
                            }
                        },*/
                        'Declare.TAKE_OFF_CITY_ID': {
                            validators: {
                                notEmpty: {
                                    message: ''
                                }
                            }
                        },
                    }
                };
            },
            headValidate: function() {
                var self = this;
                var form = $('[name="' + self.type + 'head"]');
                var setting = self.headSetting();
                form.formValidation(setting).formValidation('validate');
                var flag = form.data('formValidation').isValid();
                self.resetForm = true;
                if (flag) {
                    form.data('formValidation').resetForm();
                }
                return flag;
            },
            loadShipmentInfo: function() {
                var self = this;
                var flag = self.headValidate();
                if (flag) {
                    var data = {
                        'Declare.SCHEDULE_DATE': self.formatDate($('#' + self.type + 'date').val()),
                        'Declare.WARE_HOUSE_ID': $('[name="Declare.WARE_HOUSE_ID"]').val(),
                        'Declare.TAKE_OFF_CITY_ID': $('[name="Declare.TAKE_OFF_CITY_ID"]').val(),
                        'START_DATE': $('[name="START_DATE"]').val(),
                        'END_DATE': $('[name="END_DATE"]').val()
                    }
                    var oldData = self.info.getData();
                    for (var i = 0, l = oldData.length; i < l; i++) {
                        self.deleteInfoArr.push(oldData[i].AIR_DECLARE_INFO_ID);
                        //console.log(self.deleteInfoArr);
                    }
                    self.info = self.getGrid([], self.getInfoGridArr(), "#" + self.type + '_info');
                    self.getLoadData(data);
                } else {
                    self.notifyError({
                        title: '头表单验证',
                        text: '请完善头表单输入！'
                    });
                }

            },
            delRows: function() { //删除明细
                var self = this;
                var grid = self.info;
                var data = grid.getData();
                var row = grid.getSelectedRows(); // 获取选中行
                var delArr = [];
                if (row == '') {
                    self.notifyWarn({
                        title: '提醒',
                        text: '没有选中的行!'
                    });
                } else {
                    for (var i = 0; i < row.length; i++) {
                        if (row[i] == data.length) {
                            row.splice($.inArray(data.length, row), 1);
                        }
                    }
                    for (var i = 0; i < row.length; i++) {
                        for (var j = i + 1; j < row.length; j++) {
                            if (row[i] < row[j]) {
                                var tmp = row[i];
                                row[i] = row[j];
                                row[j] = tmp;
                            }
                        }
                    }
                    if (row.length > 0) {
                        self.notifyRemove({
                            title: '删除操作',
                            text: '确定删除该条数据，该操作不能恢复',
                            okClick: function() {
                                for (var i = 0; i < row.length; i++) {
                                    if (data[row[i]] !== undefined) {
                                        if (data[row[i]].hasOwnProperty('AIR_DECLARE_INFO_ID')) {
                                            delArr.push(data[row[i]].AIR_DECLARE_INFO_ID);
                                        }
                                    }
                                    data.splice(row[i], 1);
                                }
                                if (delArr == "") {
                                    self.deleteInfoArr = [];
                                } else {
                                    self.deleteInfoArr = delArr
                                }
                                self.billEntryListArray = data;
                                if(data.length === 0){
                                    self.unFreezeInput();
                                }
                                grid.setData(data);
                                grid.invalidateRows(row);
                                grid.updateRowCount();
                                grid.render();
                                grid.setSelectedRows([]);
                                self.filter_B_L_NUMBER_NAME(grid);
                            }
                        });
                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '没有选中的行!'
                        });
                    }
                }
            },
            getLoadData: function(data) {
                var self = this;
                var url = window.domain + '/declaremanagement/loadShipmentInfo';
                self.getMask();
                self.getAjax(url, data, function(res) {
                    self.removeMask();
                    //console.log('load return data:', res);
                    if (res.success) {
                        var arr = res.data.details;
                        if (arr.length === 0) {
                            self.notifyWarn({
                                title: '导入操作',
                                text: '数据导入成功,数据为空!'
                            })
                            self.info = self.getGridEdit([], self.getInfoGridArr(), "#" + self.type + '_info');
                            self.filter_B_L_NUMBER_NAME(self.info);
                            //self.freezeInput();
                        } else {
                            var details = [] //self.info.getData();
                            
                            var airLine ="";
                            var airLineID ="";
                            if($('#' + self.type + 'airline').val()){
                        		airLine = $('#' + self.type + 'airline').find('option:selected').html();
                            	airLineID = $('#' + self.type + 'airline').val();
                        	}
          
                            for (var j = 0, l = arr.length; j < l; j++) {
                                var params = {};
                                
                                if(arr[j].AIR_LINE_ID){
                                	params['AIR_LINE_SUPPLIER_NAME'] = arr[j].AIR_LINE_NAME;
                                    params['AIR_LINE_SUPPLIER_ID'] = arr[j].AIR_LINE_ID;
                                    params['AIR_LINE_SUPPLIER_NAME_ID'] = arr[j].AIR_LINE_ID;
                                }else{
                                	params['AIR_LINE_SUPPLIER_NAME'] = airLine;
                                    params['AIR_LINE_SUPPLIER_ID'] = airLineID;
                                    params['AIR_LINE_SUPPLIER_NAME_ID'] = airLineID;  
                                }
                                
                                params['DESTINATION_CITY_ID'] = arr[j].DEST_CITY_ID;
                                params['DESTINATION_CITY_NAME'] = arr[j].CITY_NAME;
                                params['FLIGHT_NUMBER'] = arr[j].FLIGHT_NO;
                                params['B_L_NUMBER_NAME'] = arr[j].B_L_MANAGE_NO;
                                params['B_L_MANAGE_ID'] = arr[j].B_L_MANAGE_ID;
                                params['B_L_NUMBER_NAME_ID'] = arr[j].B_L_NUMBER_NAME_ID;
                                params['BILL_NUMBER'] = arr[j].BIG_TICKET_NO;
                                params['GROCERIES'] = arr[j].IS_DECLARED == null ? 0 : arr[j].IS_DECLARED;
                                params['GOODS_TYPE_NAMES'] = arr[j].CATEGORY_NAMES;
                                params['CATEGORY_IDS'] = arr[j].CATEGORY_IDS;
                                params['GOODS_AMOUNT'] = arr[j].TOTAL_NUMBER;
                                params['GOODS_WEIGHT'] = arr[j].TOTAL_WEIGHT;
                                params['GOODS_VOLUMN'] = arr[j].TOTAL_VOLUMN;
                                params['B_NUM'] = arr[j].B_NUM == null ? '' : arr[j].B_NUM;
                                details.push(params);
                            }
                            self.info = self.getGridEdit(details, self.getInfoGridArr(), "#" + self.type + '_info'); //data['Declare.TAKE_OFF_CITY_ID']
                            self.filter_B_L_NUMBER_NAME(self.info);
                            self.freezeInput();
                            self.infoFlag = true; //标记清除
                            self.deleteInfoArr = [];
                            self.notifySuc({
                                title: '导入操作',
                                text: '数据导入成功!'
                            })
                        }

                    } else {
                        self.notifyError({
                            title: '导入操作',
                            text: '数据导入失败!'
                        });
                    }

                })
            },
            filter_B_L_NUMBER_NAME: function(grid) {
                var self = this;
                grid.onClick.subscribe(function(e, args) {
                    var itemData = args.grid.getDataItem(args.row);
                    var slickGridData = args.grid.getData();
                    if(0 == slickGridData.length){
                        self.notifyWarn({
                            title: '提单号',
                            text: '请先调入发货信息！'
                        });
                        args.grid.setData([]);
                        args.grid.render();
                        return;
                    }

                    if (args.grid.getColumns()[args.cell].field == 'B_L_NUMBER_NAME') {
                        var cityId = $('[name="Declare.TAKE_OFF_CITY_ID"]').val();
                        if(!cityId){ // 如果没有选择起飞地
                            self.notifyWarn({
                                title: '提单号',
                                text: '请先选择起飞地！'
                            });
                            return;
                        }
                        if(itemData&&itemData.AIR_LINE_SUPPLIER_NAME){
                        	if(self.type == 'create'){
                        		args.grid.getColumns()[args.cell].option.filterData = '[{"CITY_ID": ' + cityId + ',"SUPPLIER_ID":' + itemData.AIR_LINE_SUPPLIER_NAME_ID + '}]';
                        	}else{
                        		if(itemData.AIR_LINE_SUPPLIER_NAME_ID){
                        			itemData.AIR_LINE_SUPPLIER_ID = itemData.AIR_LINE_SUPPLIER_NAME_ID;
                            	}
                        		args.grid.getColumns()[args.cell].option.filterData = '[{"CITY_ID": ' + cityId + ',"SUPPLIER_ID":' + itemData.AIR_LINE_SUPPLIER_ID + '}]';
                        	}
                        }
                        // else if(itemData.AIR_LINE_SUPPLIER_ID){
                        //     args.grid.getColumns()[args.cell].option.filterData = '[{"STATUS":"NU","CITY_ID": ' + cityId + ',"SUPPLIER_ID":' + itemData.AIR_LINE_SUPPLIER_ID + '}]';
                        // }
                        else{
                            self.notifyWarn({
                                title: '提单号',
                                text: '请先选择航线！'
                            });
                        }

                        // if(args.item.hasOwnProperty('AIR_LINE_SUPPLIER_ID')){
                        //     if (args.item.AIR_LINE_SUPPLIER_ID) {
                        //         args.grid.getColumns()[args.cell].editor = Slick.Editors.selectFilter;
                        //         args.grid.getColumns()[args.cell].option.filterData = '[{"STATUS":"NU","CITY_ID": ' + cityId + ',"SUPPLIER_ID":' + args.item.AIR_LINE_SUPPLIER_ID + '}]';
                        //     }else{
                        //         self.notifyWarn({
                        //             title: '提单号',
                        //             text: '请先选择航线！'
                        //         });
                        //     }
                        // }
                        // if(args.item.hasOwnProperty('AIR_LINE_SUPPLIER_NAME_ID')){
                        //     if (args.item.AIR_LINE_SUPPLIER_NAME_ID) {
                        //         args.grid.getColumns()[args.cell].editor = Slick.Editors.selectFilter;
                        //         args.grid.getColumns()[args.cell].option.filterData = '[{"STATUS":"NU","CITY_ID": ' + cityId + ',"SUPPLIER_ID":' + args.item.AIR_LINE_SUPPLIER_NAME_ID + '}]';
                        //     }else{
                        //         self.notifyWarn({
                        //             title: '提单号',
                        //             text: '请先选择航线！'
                        //         });
                        //     }
                        // }
                    }
                });
                //航线change事件  清空提单号
                /*grid.onCellChange.subscribe(function(e,args){
                    if (args.grid.getColumns()[args.cell].field == 'AIR_LINE_SUPPLIER_NAME'){
                        args.item['B_L_NUMBER_NAME'] = '';
                        args.grid.invalidateRow(args.cell.row);
                        args.grid.render();
                    }
                });*/
            },
            freezeInput: function() {
                var self = this;
                $('#' + self.type + 'date').prop('disabled', 'true');
                $('#' + self.type + 'warehouse').prop('disabled', 'true');
                $('#' + self.type + 'flyStart').prop('disabled', 'true');
            },
            unFreezeInput: function() {
                var self = this;
                $('#' + self.type + 'date').removeProp('disabled');
                $('#' + self.type + 'warehouse').removeProp('disabled');
                $('#' + self.type + 'flyStart').removeProp('disabled');
            },
            sendData: function(arr) {
            	
                //console.log('send data into:', arr);
                var self = this;
                var params = {};
                params['Declare.SCHEDULE_DATE'] = this.formatDate($('#' + self.type + 'date').val());
                params['Declare.WARE_HOUSE_ID'] = $('#' + self.type + 'warehouse').val();
                params['Declare.CUSTOMS_BROKER_SUPPLIER_ID'] = $('#' + self.type + 'supplier').val();

                params['Declare.CHANNEL_SUPPLIER_ID'] = $('#' + self.type + 'channel').val();
                params['Declare.AIR_LINE_SUPPLIER_ID'] = $('#' + self.type + 'airline').val();

                params['Declare.IS_MCO'] = 0;
                if ($('#'+self.type +'mco').prop("checked")) {
                	params['Declare.IS_MCO'] = 1;
                }

                //MCO选中时，航线不可为空
                if ( params['Declare.IS_MCO'] == 1 ) {
                    if( $('#' + self.type + 'airline').val() ){

                    }else {
                        self.notifyError({
                            title: '操作失败',
                            text: 'MCO选中时，航线不可为空!'
                        });
                        return false;
                    }
                }

                //var infoArrId = [];
                for (var j = 0, l = arr.length; j < l; j++) { //
                    params['DeclareDetail[' + j + '].AIR_DECLARE_INFO_ID'] = arr[j].AIR_DECLARE_INFO_ID;
                    //params['DeclareDetail[' + j + '].AIR_LINE_SUPPLIER_ID'] = arr[j].AIR_LINE_SUPPLIER_ID;//arr[j].AIR_LINE_SUPPLIER_NAME_ID;

                    if(self.type == 'create'){
                    	params['DeclareDetail[' + j + '].AIR_LINE_SUPPLIER_ID'] = arr[j].AIR_LINE_SUPPLIER_NAME_ID;
                    }else{
                    	if(arr[j].AIR_LINE_SUPPLIER_NAME_ID){
                    		params['DeclareDetail[' + j + '].AIR_LINE_SUPPLIER_ID'] = arr[j].AIR_LINE_SUPPLIER_NAME_ID;
                    	}
                    	else{
                    		params['DeclareDetail[' + j + '].AIR_LINE_SUPPLIER_ID'] = arr[j].AIR_LINE_SUPPLIER_ID;//arr[j].AIR_LINE_SUPPLIER_NAME_ID;
                    	}
                    }

                    params['DeclareDetail[' + j + '].DESTINATION_CITY_ID'] = arr[j].DESTINATION_CITY_ID;
                    if (arr[j].AIR_LINE_SUPPLIER_NAME) {
                        //MCO选中时，验证单头航线，单体航线是否一致
                    	if (params['Declare.IS_MCO'] == 1 ) {
                            if(params['DeclareDetail[' + j + '].AIR_LINE_SUPPLIER_ID'] != $('#' + self.type + 'airline').val() ){
                            	self.notifyError({
                                    title: '操作失败',
                                    text: 'MCO选中时，单头航线，单体航线必须一致!'
                                });
                                return false;
                            }
                        }
                    } else {
                        self.notifyError({
                            title: '操作失败',
                            text: '报关明细 航线不能为空!'
                        });
                        self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                        return false;
                    }
                    if (arr[j].FLIGHT_NUMBER) {
                        params['DeclareDetail[' + j + '].FLIGHT_NUMBER'] = arr[j].FLIGHT_NUMBER;
                    } else {
                        self.notifyError({
                            title: '操作失败',
                            text: '航班号不能为空!'
                        });
                        self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                        return false;
                    }
                    if (arr[j].B_L_NUMBER_NAME_ID || arr[j].B_L_MANAGE_ID) {
                        params['DeclareDetail[' + j + '].B_L_NUMBER_ID'] = !!arr[j].B_L_NUMBER_NAME_ID ? arr[j].B_L_NUMBER_NAME_ID : arr[j].B_L_MANAGE_ID;
                    } else {
                    	params['DeclareDetail[' + j + '].B_L_NUMBER_ID'] = null;
                    	//MCO选中时，提单号可以为空
                    	if(params['Declare.IS_MCO'] != 1){
                    		self.notifyError({
                                title: '操作失败',
                                text: '提单号不能为空!'
                            });
                            self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                            return false;
                    	}
                    }
                    if (arr[j].CATEGORY_IDS || arr[j].GOODS_TYPE_NAMES_ID) {
                        params['DeclareDetail[' + j + '].GOODS_TYPE_IDS'] = !!arr[j].CATEGORY_IDS ? arr[j].CATEGORY_IDS : this.toStr(arr[j].GOODS_TYPE_NAMES_ID);
                    } else {
                        self.notifyError({
                            title: '操作失败',
                            text: '货物类别不能为空!'
                        });
                        self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                        return false;
                    }
                    params['DeclareDetail[' + j + '].BILL_NUMBER'] = arr[j].BILL_NUMBER;
                    params['DeclareDetail[' + j + '].GROCERIES'] = arr[j].GROCERIES == null ? 0 : arr[j].GROCERIES;
                    params['DeclareDetail[' + j + '].GOODS_AMOUNT'] = arr[j].GOODS_AMOUNT;
                    params['DeclareDetail[' + j + '].GOODS_WEIGHT'] = arr[j].GOODS_WEIGHT;
                    params['DeclareDetail[' + j + '].GOODS_VOLUMN'] = arr[j].GOODS_VOLUMN;
                    params['DeclareDetail[' + j + '].B_NUM'] = arr[j].B_NUM;
                    if(self.type === 'edit'){
                        params['DeclareDetail[' + j + '].LAST_TXN_TIME'] = arr[j].LAST_TXN_TIME//AIR_DECLARE_INFO.LAST_TXN_TIME
                    }

                    //infoArrId.push(arr[j].AIR_DECLARE_INFO_ID);
                }
                if (self.type == "create") {
                    params['Declare.TAKE_OFF_CITY_ID'] = $('#createflyStart').val();
                    params['Declare.REMARKS'] = $('#createtext').val();
                    params.pageMode = '0';
                    params.requestCode = self.requestCode;
                }
                if (self.type == "edit") {
                    params['Declare.TAKE_OFF_CITY_ID'] = $('#editflyStart').val();
                    params['Declare.REMARKS'] = $('#edittext').val();
                    params.pageMode = 2;
                    params.delDetailIds = self.deleteInfoArr.join(','); //infoArrId.join(',');
                    params['Declare.AIR_DECLARE_ID'] = self.args.AIR_DECLARE_ID;
                    params['Declare.LAST_TXN_TIME'] = self.TXN_TIME;
                    //AIR_DECLARE.LAST_TXN_TIME

                }
                params.detailLength = arr.length;
                //console.log('send before arr:', params);
                return params;
            },
            createSend: function() {
                var self = this;
                var flag = self.headValidate();
                self.info.getEditController().commitCurrentEdit();
                var infoArr = self.info.getData();
                //console.log("infoArr: ",infoArr);
                if (flag && infoArr.length > 0) {
                    var data = self.sendData(infoArr);
                    if (data) {
                        // $('[opt-type="createsave"]').prop('disabled', 'disabled');
                        self.send(data);
                    }
                    //console.log("create send: ",data);
                } else {
                    if (infoArr.length === 0) {
                        self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                    }
                    self.notifyError({
                        title: '新增操作',
                        text: '新增失败!'
                    });
                }
            },
            editSend: function() {
                var self = this;
                var flag = self.headValidate();
                var infoArr = self.info.getData();
                self.info.getEditController().commitCurrentEdit();
                //console.log('infoArr: ', infoArr);
                if (flag && infoArr.length > 0) {
                    var data = self.sendData(infoArr);
                    if (data) {
                        self.send(data);
                    }
                    // console.log("edit send", data);

                } else {
                    if (infoArr.length === 0) {
                        self.slickgridWarn($("#" + self.type + '_info'), "该表格至少传入一条数据,带*号为必填项");
                    }
                    self.notifyError({
                        title: '编辑操作',
                        text: '编辑失败!'
                    });
                }

            },
            send: function(data) {
                console.log(data)
                var self = this;
                var url = window.domain + '/declaremanagement/save';
                var tip = '';
                self.type == 'create' ? tip = '新增' : tip = '编辑';
                self.getMask();
                //setTimeout(function(){self.removeMask();}, 2000);
                //self.removeMask();
                //setTimeout(function(){btn.removeProp('disabled');}, 1000);
                self.getAjax(url, data, function(res) {
                    //console.log("return data: ", res);
                    if (res.success) {
                        self.notifySuc({
                            title: tip + '操作',
                            text: '数据' + tip + '成功!'
                        })
                        //self.info = self.getGridEdit([], self.getInfoGridArr(), "#" + self.type + '_info');
                        //self.file = self.getGridEdit([], self.getFileGridArr(), "#" + self.type + '_file');
                        $('.modal').modal('hide');
                        self.$emit("suc", { INFO_ID: res.data.INFO_ID }); //跳转弹窗
                    }
                    if (!res.success) {
                        if (res.msg !== undefined) {
                            self.notifyError({
                                title: '操作',
                                text: res.msg
                            });
                            
                        } else {
                            self.notifyError({
                                title: tip + '操作',
                                text: res.message||'数据' + tip + '失败!'
                            });
                            switch (res.message) {
                                case 'GOODS_TYPE_IDS is required.':
                                    self.slickgridWarn($("#" + self.type + '_info'), "货物类别不能为空！");
                                    break;
                                case 'FLIGHT_NUMBER is required.':
                                    self.slickgridWarn($("#" + self.type + '_info'), "航班号不能为空！");
                                    break;
                                case 'B_L_NUMBER_NAME is required.':
                                    self.slickgridWarn($("#" + self.type + '_info'), "提单号不能为空！");
                                    break;
                                case 'CHECK_AIRLINESUPPLIER_BLMANAGE':
                                    self.slickgridWarn($("#" + self.type + '_info'), "航线、提单号必须对应，请输入正确的航线、提单号！");
                                    break;
                            }
                        }
                    }
                    self.removeMask();
                })
            },
            toStr: function(arr) {
                if (Array.isArray(arr)) {
                    return arr.join(',');
                }
                return arr;
            },
            deleteObj: function(obj) {
                for (var key in obj) {
                    delete obj.key;
                }
                return;
            },
            flushInfoGrid: function(){
            	var self = this;
            	$('#' + self.type + 'mco').on('change', function(e){
                	var that = $(this);
                	$(document).trigger('validate:grid');
                	if(that.prop('checked')){
                		
                	}
                });
            	setTimeout(function(){
        			$('#' + self.type + 'airline').on('change', function(e){
            			$(document).trigger('validate:grid');
            		})
        		}, 50)
                $(document).off('validate:grid').on('validate:grid', function(e, res){
                	var data = self.info.getData();
                	if($('#' + self.type + 'airline').val() && $('#' + self.type + 'mco').prop('checked')){
                		if(data.length > 0){
                    		var airLine = $('#' + self.type + 'airline').find('option:selected').html();
                        	var airLineID = $('#' + self.type + 'airline').val();
                    		for(var i=0; i<data.length; i++){
                    			data[i]['AIR_LINE_SUPPLIER_NAME'] =  airLine;
                    			data[i]['AIR_LINE_SUPPLIER_NAME_ID'] =  airLineID;
                    		}
                    		self.info = self.getGridEdit(data, self.getInfoGridArr(), "#" + self.type + '_info');
                    	}
                	}else{
                		if(data.length > 0){
                			for(var i=0; i<data.length; i++){
                    			data[i]['AIR_LINE_SUPPLIER_NAME'] =  null;
                    			data[i]['AIR_LINE_SUPPLIER_NAME_ID'] = null;
                    		}
                			self.info = self.getGridEdit(data, self.getInfoGridArr(), "#" + self.type + '_info');
                		}
                	}
                	self.filter_B_L_NUMBER_NAME(self.info);
                })
            }
        },

        props: {
            type: {
                type: String,
                required: true
            }
        },
        watch: {
            args: function(val, old) {
                //console.log("watch args", val);
            },
            argsFlag: function(val, old) {
                var self = this;
                self.show = true;

                if (self.type === 'create') {
                    $(self.$el).trigger('create');
                    $('#' + self.type + 'date').val(self.getDateStr(0)).trigger('change');
                    $('[name="Declare.WARE_HOUSE_ID"]').val(null).trigger('change');
                    $('[name="Declare.CUSTOMS_BROKER_SUPPLIER_ID"]').val(null).trigger('change');
                    $('[name="Declare.TAKE_OFF_CITY_ID"]').val(null).trigger('change');

                    $('[name="Declare.CHANNEL_SUPPLIER_ID"]').val(null).trigger('change');
                    $('[name="Declare.AIR_LINE_SUPPLIER_ID"]').val(null).trigger('change');

                    $('[name="Declare.IS_MCO"]').prop("checked",false); 
                }
                if (self.type === 'detail') {
                    $(self.$el).trigger('detail', { INFO_ID: self.args.AIR_DECLARE_ID });
                }
                if (self.type === 'edit') {
                    $('#' + self.type + 'date').val(self.args.SCHEDULE_DATE);
                    $('#' + self.type + 'warehouse').val(self.args.WARE_HOUSE_ID).trigger('change');
                    
                    //$('#' + self.type + 'supplier').val(self.args.CUSTOMS_BROKER_SUPPLIER_ID).trigger('change');
                    $('#' + self.type + 'supplier').html("<option value='"+self.args.CUSTOMS_BROKER_SUPPLIER_ID+"'>"+self.args.CUSTOMS_BROKER_SUPPLIER_NAME+"</option>");
                    $('#' + self.type + 'supplier').val(self.args.CUSTOMS_BROKER_SUPPLIER_ID).trigger('change');
                    
                    var option = '<option value="' + self.args.TAKE_OFF_CITY_ID + '">' + self.args.TAKE_OFF_CITY_NAME + '</option>';
                    $('[name="Declare.TAKE_OFF_CITY_ID"]').html(option).val(self.args.TAKE_OFF_CITY_ID).trigger('change'); //
                    $('[name="Declare.REMARKS"]').val(self.args.REMARKS);

                    //$('#' + self.type + 'channel').val(self.args.CHANNEL_SUPPLIER_ID).trigger('change');
                    $('#' + self.type + 'channel').html("<option value='"+self.args.CHANNEL_SUPPLIER_ID+"'>"+self.args.CHANNEL_SUPPLIER_NAME+"</option>");
                    $('#' + self.type + 'channel').val(self.args.CHANNEL_SUPPLIER_ID).trigger('change');
                    
                    //$('#' + self.type + 'airline').val(self.args.AIR_LINE_SUPPLIER_ID).trigger('change');
                    $('#' + self.type + 'airline').html("<option value='"+self.args.AIR_LINE_SUPPLIER_ID+"'>"+self.args.AIR_LINE_SUPPLIER_NAME+"</option>");
                    $('#' + self.type + 'airline').val(self.args.AIR_LINE_SUPPLIER_ID).trigger('change');

                    if(self.args.IS_MCO && self.args.IS_MCO == 1){
                    	$('#'+self.type +'mco').prop("checked",true);
                    }else{
                    	$('#'+self.type +'mco').prop("checked",false);
                    }

                    $(self.$el).trigger('edit', { INFO_ID: self.args.AIR_DECLARE_ID });
                }
            },
            createFlag: function(val, old) {
                this.createSend();
            },
            editFlag: function(val, old) {
                this.editSend();
            }
        },
        mounted: function() {
            var self = this;
            $('.modal').on('show.bs.modal', function(e) {
                self.getDate($('#' + self.type + 'date'));

                self.getDate($('#' + self.type + 'startdate'));
                self.getDate($('#' + self.type + 'enddate'));

                $(self.$el).off('create').on('create', function(e, res) {
                    self.info = self.getGridEdit([], self.getInfoGridArr(), "#" + self.type + '_info');
                    self.filter_B_L_NUMBER_NAME(self.info);
                    self.file = self.getGridEdit([], self.getFileGridArr(), "#" + self.type + '_file');

                    var url = window.domain + '/declaremanagement/applyRequestCode';
                    self.getAjax(url, {}, function(res) {
                        self.requestCode = res.data.requestCode;
                        //console.log('requestCode: ', self.requestCode);
                    });
                    self.flushInfoGrid();
                })
                $(self.$el).off('detail').on('detail', function(e, res) {
                    //console.log("res: ", res);
                    var url = window.domain + "/declaremanagement/openRow";
                    self.getMask('white');
                    self.getAjax(url, res, function(args) {
                        self.removeMask();
                        if (args.success) {
                            //console.log("detail return data: ", args);
                            $(document).trigger('TIME', {time: args.data.headData.LAST_TXN_TIME});
                            self.detailArgs = args.data.headData;
                            //head set Data

                            for (var i = 0, l = args.data.detailData.length; i < l; i++) {
                                args.data.detailData[i].GOODS_STATUS = self.stateFilter(args.data.detailData[i].GOODS_STATUS);
                            }
                            self.info = self.getGrid(args.data.detailData, self.getInfoGridArr(), "#" + self.type + '_info');
                            self.file = self.getGrid(args.data.uploadFilesList, self.getFileGridArr(), "#" + self.type + '_file');
                        } else {
                            self.notifyError({
                                title: '初始化操作',
                                text: '获取数据失败!'
                            });
                        }
                    })
                });
                $(self.$el).off('edit').on('edit', function(e, res) {
                    //console.log("res: ", res);
                    var url = window.domain + "/declaremanagement/openRow";
                    self.getMask('white');
                    self.getAjax(url, res, function(args) {
                        self.removeMask();
                        //console.log("edit return data: ", args);
                        if (args.success) {
                            for (var i = 0, l = args.data.detailData.length; i < l; i++) {
                                args.data.detailData[i].B_L_NUMBER_NAME_ID = args.data.detailData[i].B_L_NUMBER_ID;
                                args.data.detailData[i].GOODS_TYPE_NAMES_ID = args.data.detailData[i].GOODS_TYPE_IDS;
                            }
                            self.TXN_TIME = args.data.headData.LAST_TXN_TIME;
                            self.info = self.getGridEdit(args.data.detailData, self.getInfoGridArr(), "#" + self.type + '_info');
                            self.filter_B_L_NUMBER_NAME(self.info); //filter_B_L_NUMBER_NAME: function(grid, cityId)
                            self.freezeInput();
                            self.file = self.getGridEdit(args.data.uploadFilesList, self.getFileGridArr(), "#" + self.type + '_file');
                        } else {
                            self.notifyError({
                                title: '初始化操作',
                                text: '获取数据失败!'
                            });
                        }
                    })
                    self.flushInfoGrid();
                })
            });
            $('.modal').on('hide.bs.modal', function(e) {
                //self.deleteObj(self.args);
                if (self.resetForm) {
                    $('[name="' + self.type + 'head"]').data('formValidation').resetForm();
                    $("#" + self.type + '_info').trigger('click');
                }
                $('textarea').val('');
                if (self.infoFlag) {
                    self.info = self.getGridEdit([], self.getInfoGridArr(), "#" + self.type + '_info');
                }
                if (self.fileFlag) {
                    self.file = self.getGridEdit([], self.getFileGridArr(), "#" + self.type + '_file');
                }
                $('#' + self.type + 'airline').val(null).trigger("change");
                self.unFreezeInput();
            });
        },
        mixins: [util, notify]
    });
})