requirejs.config({
    paths: {
        edit: '../../module/declareManagement/view/edit.html',
    }
});
define(['vue', 'text!edit', 'util', 'M'], function(Vue, edit, util) {
    Vue.component('edit', {
        template: edit,
        data: function() {
            return {
                args: {},
                argsFlag: false
            }
        },
        methods: {
            sendMsg: function(){
                this.$refs.page.editFlag = !this.$refs.page.editFlag
            },
            editSuc: function(res){
               this.$emit('reload', res);
            }
        },
        mounted: function() {
            
        },
        watch: {
            args: function(val, old){
               
            },
            argsFlag: function(val, old){
                this.$refs.page.args = this.args;
                this.$refs.page.argsFlag = !this.$refs.page.argsFlag;
                //console.log(this.args);
            }
        },
        props: {
            mid: {
                type: String,
                required: true
            }
        },
        mixins: [util]
    });
})
