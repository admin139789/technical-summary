requirejs.config({
    paths: {
        detail: '../../module/declareManagement/view/detail.html'
    }
});
define(['vue', 'text!detail', 'util', 'notify', 'M'], function(Vue, detail, util, notify) {
    Vue.component('detail', {
        template: detail,
        data: function() {
            return {
                args: {},
                argsFlag: false,
                time: '',
                lockID: ''
            }
        },
        methods: {
        	// 请求后台加锁
        	checkLock: function(){
            	var self = this;
            	self.lockID = '';
            	$.ajax({
            		type: "post",
            		url: window.domain+"/lock/checkLock",
            		async: false,
            		data: {
            			TYPE: 7, // 1: 收款单 2：付款单 3：成本录入 4：账单录入，7：报关  这个是账单录入模块，所以是4
            			BUSSINESS_ID: self.args.AIR_DECLARE_ID,
            		},
            		success: function(data){
            			if(data.isSuccess&&data.isNotExist){ // 
            				self.lockID = data.lock_ID;
            			}else{
            				self.notifyError({
                                title: '提示',
                                text: '数据处理中!'
                            })
            			}
            		},
            		error:function(result){
                        self.notifyError({
                            title: '提示',
                            text: '请求失败!'
                        })
                    }
            	});
            },
        	refer: function() {
                var self = this;
                // 判断有没有加锁，如果加锁就表明数据正在操作中不能再操作
                self.checkLock();
                if(!self.lockID){
                	return;
                }
                
                if (self.args.CURRENT_STATUS === "MB") {
                    var data = { 
                        'Declare.AIR_DECLARE_ID': self.args.AIR_DECLARE_ID,
                        'Declare.LAST_TXN_TIME': self.time,//self.args.LAST_TXN_TIME,
                        'action': "SUBMIT",
                        'lockID': self.lockID // lockID 是不是后台正在处理上一次审批
                    };
                    var url = window.domain + "/declaremanagement/changeDeclareStatus";
                    self.getMask();
                    self.getAjax(url, data, function(args) {
                    	self.removeMask();
                        if (args.success) {
                            self.notifySuc({
                                title: "提交操作",
                                text: '数据提交成功"'
                            });
                            self.$emit('reload', { type: 'detail' });
                            self.argsFlag = !self.argsFlag;
                            self.args.CURRENT_STATUS = "SD";
                        }else {
                            self.notifyError({
                                title: '提交操作',
                                text: '提交失败!'
                            });
                        }                        
                    })
                } else {
                    self.notifyWarn({
                        title: '提醒',
                        text: '数据状态已不能提交!'
                    });
                }
            },
            cutout: function() {
                var self = this;                
                if (self.args.CURRENT_STATUS === "SD") {
                    // btn.prop('disabled', 'disabled');
                    var data = { 
                        'Declare.AIR_DECLARE_ID': self.args.AIR_DECLARE_ID, 
                        'Declare.LAST_TXN_TIME': self.time,//self.args.LAST_TXN_TIME,
                        'action': "TEMINATE"
                     };
                    var url = window.domain + "/declaremanagement/changeDeclareStatus";
                    self.getMask();
                    self.getAjax(url, data, function(args) {
                    	self.removeMask();
                        if (args.success) {
                            self.notifySuc({
                                title: "终止操作",
                                text: "数据终止成功！"
                            });
                            self.$emit('reload', { type: 'detail' });
                            self.argsFlag = !self.argsFlag;
                        } else {
                            self.notifyError({
                                title: '终止操作',
                                text: '终止失败!'
                            });
                        }                        
                    })
                } else {
                    self.notifyWarn({
                        title: '提醒',
                        text: '数据状态还未提交，不能终止!'
                    });
                }
              // setTimeout(function(){btn.removeProp('disabled');}, 1000);
            }
        },
        mounted: function() {
            var self = this;
            $(document).on('TIME', function(e, res){
               self.time = res.time;
            })
        },
        watch: {
            args: function(val, old) {
                //this.$refs.page.args = val;
            },
            argsFlag: function(val, old) {
                this.$refs.page.args = this.args;
                this.$refs.page.argsFlag = !this.$refs.page.argsFlag;
            }
        },
        props: {
            mid: {
                type: String,
                required: true
            }
        },
        mixins: [util, notify]
    });
})