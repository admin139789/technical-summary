requirejs.config({
    paths: {
        tbHtml: '../../module/declareManagement/view/table.html',
    }
});
define(['vue', 'text!tbHtml', 'DTM','util','DT'], function(Vue, h, DTM,util) {
    Vue.component('vtable', {
        template: h,
        mounted: function() {
            var self = this;
            var el = $(self.$el);
            var url = window.domain + '/declaremanagement/listPage';
            self.table = self.getTable(url, el, "zh_CN");
            self.selectBind(el);
        },
        methods: {
            getTable: function(url, el, lg) {
                var self = this;
                self.getMask();
                var table = el.DataTable({
                    dom: 'Ztl<"fr"ip>',
                    lengthMenu: [
                        [5, 10, 20, 30, 50, 100, 500],
                        [5, 10, 20, 30, 50, 100, 500]
                    ],
                    serverSide: true,
                    processing: true,
                    pageLength: 10, //每页的大小
                    ajax: {
                        "url": url,
                    },
                    columns: [{
                            data: null,
                            defaultContent: '',
                            className: 'select-checkbox',
                            style: "os",
                            orderable: false
                        },
                        { data: 'BILLNUMBER' },
                        { data: 'CURRENT_STATUS',width:'50px' },
                        { data: 'SCHEDULE_DATE' },
                        { data: 'WARE_HOUSE_NAME' },
                        { data: 'CUSTOMS_BROKER_SUPPLIER_NAME',width:'200px' },
                        { data: 'B_L_NUMBERS' ,width:'200px'},
                        { data: 'REMARKS' }
                    ],
                    columnDefs: [{
                        targets: 2,
                        render: function(data, type, row, meta) {
                            return self.stateFilter(data);
                        }
                    }],
                    order: [1, 'desc'],
                    "bFilter": true,
                    colReorder: {
                        dataSrc: 'readingOrder',
                    },
                    "language": {
                        url: window.domain + '/static/language/' + lg + '.json'
                    },
                    drawCallback: function() {
                        $(document).trigger('title');
                    },
                    initComplete: function() {
                        $(document).trigger('title');
                        self.removeMask();
                    }
                });
                return table;
            }
        },
        mixins: [DTM,util],
    });


})
