requirejs.config({
    paths: {
        create: '../../module/declareManagement/view/create.html',
        page: '../../module/declareManagement/page',
    }
});
define(['vue', 'text!create', 'util', 'M', 'page'], function(Vue, create, util) {
    Vue.component('create', {
        template: create,
        data: function() {
            return {
                args: {},
                argsFlag: false
            }
        },
        methods: {
            sendMsg: function() {
                this.$refs.page.createFlag = !this.$refs.page.createFlag
            },
            createSuc: function(res) {
                this.$emit('reload', res);
            }
        },
        mounted: function() {
            var self = this;

        },
        watch: {
            argsFlag: function(val, old) {
                this.$refs.page.argsFlag = !this.$refs.page.argsFlag;
            }
        },
        props: {
            mid: {
                type: String,
                required: true
            }
        },
        mixins: [util]
    });
})
