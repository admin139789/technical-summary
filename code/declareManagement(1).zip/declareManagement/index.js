requirejs.config({
    paths: {
        table: '../../module/declareManagement/table',
        detail: '../../module/declareManagement/detail',
        create: '../../module/declareManagement/create',
        edit: '../../module/declareManagement/edit',

    }
});
requirejs(['vue', 'notify', 'init', 'util', 'table', 'selectfilter', 'validateBT', 'detail', 'create', 'edit'], function(Vue, notify, init, util) {
    var vm = new Vue({
        el: '#declareManagement',
        data: {
            SCHEDULE_DATE: $('[name="Declare.SCHEDULE_DATE"]').val()
        },
        mounted: function() {
            this.createM = this.$refs.create;
            this.table = this.$refs.tb.table;
            this.list = this.$refs.list;
            this.update = this.$refs.edit;
            this.rangDateNoToday($('#date'), $('#endDate'));
        },
        methods: {
            reload: function(res) {
                var self = this;
                var page = self.table.page();
                //this.table.ajax.reload();//刷新待选
                //console.log("reload event data:", res)
                self.table.page(page).draw('page');//恢复操作页面
                /*
                if(res.type === 'detail'){
                    self.table.page(page).draw('page');//恢复操作页面
                    return;
                }
                setTimeout(function() {
                    self.detail("",{AIR_DECLARE_ID: res.INFO_ID});
                    self.table.page(page).draw('page');//恢复操作页面
                }, 500);*/
            },
            detail: function(e, res) {
                var self = this;
                if (res) {
                    $('#detailModal').modal('show');
                    self.list.args = res;
                    self.list.argsFlag = !self.list.argsFlag;
                } else {
                    console.log(selectData)
                    var selectData = self.table.rows('.selected').data();
                    //console.log("detail select: ",selectData[0]);
                    if (selectData.length === 0) {
                        self.notifyWarn({
                            title: "提醒",
                            text: '请先选择一条报关信息！'
                        });
                    } else {
                        self.list.args = selectData[0];
                        self.list.argsFlag = !self.list.argsFlag;
                        $('#detailModal').modal('show');
                    }
                }
            },
            create: function() {
                var self = this;
                $('#createModal').modal('show');
                self.createM.argsFlag = !self.createM.argsFlag;
            },
            edit: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();
                //console.log("edit data:", selectData);
                if (selectData.length === 0) {
                    self.notifyWarn({
                        title: "提醒",
                        text: '请先选择一条报关信息！'
                    });
                } else {
                    if (selectData[0].CURRENT_STATUS === "MB") {
                        self.update.args = selectData[0];
                        self.update.argsFlag = !self.update.argsFlag;
                        $('#editModal').modal('show');

                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '数据状态已不能修改!'
                        });
                    }
                }
            },
            /*
            refer: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();
                if (selectData.length === 0) {
                    self.notifyWarn({
                        title: "提醒",
                        text: '请先选择一条报关信息！'
                    });
                } else {
                    if (selectData[0].CURRENT_STATUS === "MB") {
                        self.notifyConfirm({
                            title: '提交操作',
                            text: '确定提交该条数据吗？',
                            okClick: self.submit
                        });

                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '数据状态已不能提交!'
                        });
                    }

                }
            },
            submit: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();

                var data = { 'Declare.AIR_DECLARE_ID': selectData[0].AIR_DECLARE_ID, 'action': "SUBMIT" };
                var url = window.domain + "/declaremanagement/changeDeclareStatus";
                self.getAjax(url, data, function(args) {
                    //console.log("submit:", args);
                    if (args.success) {
                        self.notifySuc({
                            title: "提交操作",
                            text: '数据提交成功"'
                        });
                        self.table.ajax.reload();
                    }
                })
            },
            cutout: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();
                // console.log(selectData[0]);
                if (selectData.length === 0) {
                    self.notifyWarn({
                        title: "提醒",
                        text: '请先选择一条报关信息！'
                    });
                } else {
                    if (selectData[0].CURRENT_STATUS === "SD") {
                        self.notifyConfirm({
                            title: '终止操作',
                            text: '确定终止该条数据吗？',
                            okClick: self.cutoutFunc
                        });
                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '数据状态还未提交，不能终止!'
                        });
                    }

                }
            },
            cutoutFunc: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();

                var data = { 'Declare.AIR_DECLARE_ID': selectData[0].AIR_DECLARE_ID, 'action': "TEMINATE" };
                var url = window.domain + "/declaremanagement/changeDeclareStatus";
                self.getAjax(url, data, function(args) {
                    //console.log("teminate", args);
                    if (args.success) {
                        self.notifySuc({
                            title: "终止操作",
                            text: "数据终止成功！"
                        });
                        self.table.ajax.reload();
                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '该数据不能终止!'
                        });
                    }
                })
            },*/
            remove: function(e) {
                var self = this;
                var selectData = self.table.rows('.selected').data();
                if (selectData.length === 0) {
                    self.notifyWarn({
                        title: "提醒",
                        text: '请先选择一条报关信息！'
                    });
                } else {
                    //console.log(selectData[0]);
                    if (selectData[0].CURRENT_STATUS === "MB") {
                        self.notifyRemove({
                            title: '删除操作',
                            text: '确定删除该条数据，该操作不能恢复',
                            okClick: self.removeSuc
                        });

                    } else {
                        self.notifyWarn({
                            title: '提醒',
                            text: '数据状态已不能修改!'
                        });
                    }

                }
            },
            removeSuc: function() {
                var self = this;
                var selectData = self.table.rows('.selected').data();
                //$('[opt-type="delete"]').prop('disabled', 'disabled');
                self.getMask();
                //setTimeout(function(){self.removeMask();}, 2000);
                //self.removeMask();
                var data = { 
                    'Declare.AIR_DECLARE_ID': selectData[0].AIR_DECLARE_ID,
                    'Declare.LAST_TXN_TIME': selectData[0].LAST_TXN_TIME
                 };
                // console.log('delete data: ', data);
                var url = window.domain + "/declaremanagement/delete";
                self.getAjax(url, data, function(args) {
                    //console.log(args);
                    if (args.success) {
                        self.notifySuc({
                            title: "删除操作",
                            text: "删除成功！"
                        });
                        self.table.ajax.reload();
                    }
                    //$('[opt-type="delete"]').removeProp('disabled');
                    self.removeMask();
                })
            },

            search: function() {
                var self = this;
                var filterData = [{
                        "key": "SCHEDULE_DATE",
                        "opr": "GE",
                        "value": !!($('#date').val()) ? self.formatDate($('#date').val()) : null,
                        "valueType": "Date"
                    },
                    {
                        "key": "SCHEDULE_DATE",
                        "opr": "LE",
                        "value": !!($('#endDate').val()) ? self.formatDate($('#endDate').val()) : null,
                        "valueType": "Date"
                    },
                    {
                        "key": "WARE_HOUSE_ID",
                        "opr": "EQ",
                        "value": $('#warehouse').val()
                    },
                    {
                        "key": "CUSTOMS_BROKER_SUPPLIER_ID",
                        "opr": "EQ",
                        "value": $('#supplier').val()
                    },
                    {
                        "key": "CURRENT_STATUS",
                        "opr": "EQ",
                        "value": $('#state').val()
                    }
                ];

                var sendData = [];
                for (var i = 0, l = filterData.length; i < l; i++) {
                    if (filterData[i].value) {
                        sendData.push(filterData[i]);
                    }
                }
                //console.log('filterData: ', sendData);
                self.table.ajax.url(window.domain + "/declaremanagement/listPage?queryConditions=" + JSON.stringify(sendData));
                self.table.ajax.reload();
                self.notifySuc({
                    title: '搜索操作',
                    text: '搜索成功！'
                });
            },
            reset: function() {
                $('#date').val(null);
                $('#endDate').val(null);
                $('#warehouse').val(null).trigger('change');
                $('#supplier').val(null).trigger('change');
                $('#flyStart').val(null).trigger('change');
                $('#state').val(null);
                this.notifySuc({
                    title: "重置操作",
                    text: '重置成功"'
                });
            },
            print: function() {

            }
        },
        mixins: [notify, init, util]
    })
});